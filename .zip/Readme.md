git hub: https://github.com/rohannsahh/session-management  
architecture diagram: https://miro.com/app/board/uXjVLxcbX3A=/?share_link_id=16044814265  
video demonstration:
